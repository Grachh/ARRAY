/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



import java.util.Scanner;

/**
 *
 */
public class Ejercicio8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Introduzca un número: ");
        Scanner sc = new Scanner(System.in);
        int numero = sc.nextInt();
        System.out.print("Factorial de " + numero);

        int factorial = 1;
        while (numero > 0) factorial *= numero--;

        System.out.println(" = " + factorial);

    }

}
