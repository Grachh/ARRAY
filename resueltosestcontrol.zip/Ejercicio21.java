/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



import java.util.Scanner;

/**
 *
 */
public class Ejercicio21 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca un numero: ");
      int numero = sc.nextInt();

      int suma = 0;
        System.out.print("Divisores de " + numero + " : ");
      for (int i=1; i<numero; i++) {
        if (numero % i == 0) {
            System.out.print(i + ", ");
            suma += i;
        }
      }
        System.out.println("");
        if (suma == numero) System.out.print("Es ");
        else System.out.print("No es ");
        System.out.println(" un numero perfecto");
    }

}
