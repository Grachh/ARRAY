/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 */
public class Ejercicio7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      for(int i=1; i<=100; i++) {
          if (i % 3 == 0) System.out.print("Saca");

          if (i % 5 == 0) System.out.print("Corchos");

          else if (i % 3 != 0) System.out.print(i);

          System.out.println("");
      }
    }

}
