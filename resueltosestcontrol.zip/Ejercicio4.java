/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 */
public class Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        for (int i=1; i<=10; i++) {
            if (i % 2 == 0) System.out.println(i + " es par");
            else            System.out.println(i + " es impar");
        }
    }

}
