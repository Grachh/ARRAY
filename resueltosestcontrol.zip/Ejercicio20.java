/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 */
public class Ejercicio20 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double valor_nuevo = 1;

        int n = 1;
        boolean precision_alcanzada = false;
        double valor_antiguo, valor_menosuno;
        while (!precision_alcanzada) {

            valor_antiguo = valor_nuevo;
            valor_menosuno = (n % 2 == 0) ? 1 : -1;
            valor_nuevo = valor_antiguo + valor_menosuno / (2 * n + 1);

            if (Math.abs(4 * valor_nuevo - 4 * valor_antiguo) < 0.0001) {
                precision_alcanzada = true;
            }
            n++;

        }

        System.out.println("El valor de Pi con cuatro decimales es: " + 4 * valor_nuevo);
    }
}
