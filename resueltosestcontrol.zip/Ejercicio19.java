/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.Scanner;

/**
 *
 */
public class Ejercicio19 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Primer Cuadrado");
        System.out.println("Introduzca la x");
        int x1 = sc.nextInt();
        System.out.println("Introduzca la y");
        int y1 = sc.nextInt();
        System.out.println("Introduzca el lado");
        int l1 = sc.nextInt();

        System.out.println("Segundo Cuadrado");
        System.out.println("Introduzca la x");
        int x2 = sc.nextInt();
        System.out.println("Introduzca la y");
        int y2 = sc.nextInt();
        System.out.println("Introduzca el lado");
        int l2 = sc.nextInt();

        boolean c1izqdec2    = (x1 + l1) < x2;
        boolean c1abajodec2  = (y1 + l1) < y2;
        boolean c1dchadec2   = x1 > (x2 + l2);
        boolean c1arribadec2 = y1 > (y2 + l2);
        boolean secortan     = !(c1izqdec2 || c1abajodec2 || c1dchadec2 || c1arribadec2);

        if (x1 < x2 && y1 < y2 && (x2 + l2) < (x1 + l1) && (y2 + l2) < (y1 + l1)) {
            System.out.println("Cuadrado1 incluye al 2");
        } else if (x2 < x1 && y2 < y1 && (x1 + l1) < (x2 + l2) && (y1 + l1) < (y2 + l2)) {
            System.out.println("Cuadrado2 incluye al 1");
        } else if (secortan) {
            System.out.println("Se cortan");
        } else {
            System.out.println("Ni están incluidos ni se cortan");
        }

    }
}
