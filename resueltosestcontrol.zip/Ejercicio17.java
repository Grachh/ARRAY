/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



import java.util.Scanner;

/**
 *
 */
public class Ejercicio17 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Introduzca el numero de enteros que se van a leer:");
        Scanner sc = new Scanner(System.in);
        int numvalores = sc.nextInt();

        int maximo=0, minimo=0, suma=0, tmp;
        for (int i=0; i<numvalores; i++) {
            System.out.println("Introduzca un valor:");
            tmp = sc.nextInt();

            if (i==0) maximo = minimo = tmp;
            else {
              if (tmp > maximo) maximo = tmp;
              else if (tmp < minimo) minimo = tmp;
            }

            suma += tmp;
        }

        System.out.println("Maximo: " + maximo);
        System.out.println("Minimo: " + minimo);
        System.out.println("Media: " + (double)suma/(double)numvalores);
    }

}
