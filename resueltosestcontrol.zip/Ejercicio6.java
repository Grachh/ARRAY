/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 */
public class Ejercicio6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

      int mayoresque3 = 0;
      for (int i=1; i<=10; i++) {
          if (i > 3) mayoresque3++;
      }
        System.out.println("Resultado: " + mayoresque3);
    }

}
