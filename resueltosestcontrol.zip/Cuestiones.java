/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 * @author santi
 */
public class Cuestiones {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
for (int i = 0; i < 10; i = i + 2)
        System.out.println(i);
for (int i = 100; i >= 0; i = i - 7)
       System.out.println(i);
   for (int i = 1; i <= 10; i = i + 1)
       System.out.println(i);
   for (int i = 2; i < 100; i = i * 2)
       System.out.println(i);


    }

}
