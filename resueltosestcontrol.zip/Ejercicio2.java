/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      for (int i=1; i<=20; i++) {
          System.out.println(i + " cuadrado: " + i * i);
      }
    }

}
