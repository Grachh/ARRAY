/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



import java.util.Scanner;

/**
 *
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      final double PI = 3.1416;

      System.out.println("Escriba el radio: ");
      Scanner sc = new Scanner(System.in);
      double radio = sc.nextDouble();

      double area = PI * radio * radio;
      
      System.out.println("Area circulo: " + area);
    }

}
