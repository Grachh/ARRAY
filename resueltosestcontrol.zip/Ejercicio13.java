/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



import java.util.Scanner;

/**
 *
 */
public class Ejercicio13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Introduzca el valor de N: ");
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        for (int i=n; i>=1; i--) {
            for (int j=1; j<=i; j++) {
                if (j==i)  System.out.print("+");
                else       System.out.print("*");
            }
            System.out.println("");
        }
    }

}
