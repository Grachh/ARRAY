/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.Scanner;

/**
 *
 */
public class Ejercicio18 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Introduzca el numero de enteros que se van a leer:");
        Scanner sc = new Scanner(System.in);
        int numvalores = sc.nextInt();

        int numsuspensos = 0, numaprobados = 0, numnotables = 0, numsobre = 0;
        double tmp, suma=0.0;
        
        for (int i = 0; i < numvalores; i++) {
            System.out.println("Introduzca un valor");
            tmp = sc.nextDouble();

            if      (tmp >=9) numsobre++;
            else if (tmp >=7) numnotables++;
            else if (tmp >=5) numaprobados++;
            else              numsuspensos++;

            suma += tmp;
        }

        System.out.println("Nº Sobresalientes: " + numsobre);
        System.out.println("Nº Notables: " + numnotables);
        System.out.println("Nº Aprobados: " + numaprobados);
        System.out.println("Nº Suspensos: " + numsuspensos);

        double media = (double) suma / numvalores;
        System.out.print("Media: " + media + " Calificación de ");

        if      (media >= 9) System.out.println("sobresaliente");
        else if (media >= 7) System.out.println("Notable");
        else if (media >= 5) System.out.println("Aprobado");
        else                 System.out.println("Suspenso");
    }
}
