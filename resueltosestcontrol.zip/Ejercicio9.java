/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.Scanner;

/**
 *
 */
public class Ejercicio9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca la x: ");
        int x = sc.nextInt();
        System.out.println("Introduzca la y: ");
        int y = sc.nextInt();
        if (x > 0) {
            if (y > 0) {
                System.out.println("Noreste");
            } else if (y == 0) {
                System.out.println("Este");
            } else {
                System.out.println("Sureste");
            }
        } else if (x == 0) {
            if (y > 0) {
                System.out.println("Norte");
            }
            else if (y < 0) {
                System.out.println("Sur");
            }
        } else {
            if (y > 0) {
                System.out.println("Noroeste.\n");
            } else if (y == 0) {
                System.out.println("Oeste");
            } else {
                System.out.println("Suroeste.\n");
            }
        }

    }
}
