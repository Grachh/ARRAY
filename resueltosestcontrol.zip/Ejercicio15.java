/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.Scanner;

/**
 *
 */
public class Ejercicio15 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca la x:");
        int x = sc.nextInt();
        System.out.println("Introduzca la y:");
        int y = sc.nextInt();
        double total = 1;
        for (int i = 0; i < y; i++, total *= x){}

        System.out.println("Total de x " + " elevado a " + y + " : " + total);
    }
}
