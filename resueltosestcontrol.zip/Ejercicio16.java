/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 */
public class Ejercicio16 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("0\n1");
        int anterior = 0;
        int actual = 1;
        int tmp;

        for (int i = 1; i <= 8; i++) {
            tmp = actual + anterior;
            anterior = actual;
            actual = tmp;
            System.out.println(actual);
        }
    }
}
