/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Scanner;

/**
 *
 */
public class Ejercicio14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca un cantidad: ");
        double cantidad = sc.nextDouble();

        int unidades;
        double valormoneda;

        valormoneda = 20;
        if (cantidad >= valormoneda) {
            unidades = (int) (cantidad / valormoneda);
            cantidad = cantidad % valormoneda;
            System.out.println("Nº billetes " + valormoneda + " : " + unidades);
        }
        valormoneda = 10;
        if (cantidad >= valormoneda) {
            unidades = (int) (cantidad / valormoneda);
            cantidad = cantidad % valormoneda;
            System.out.println("Nº billetes " + valormoneda + " : " + unidades);
        }
        valormoneda = 2;
        if (cantidad >= valormoneda) {
            unidades = (int) (cantidad / valormoneda);
            cantidad = cantidad % valormoneda;
            System.out.println("Nº billetes " + valormoneda + " : " + unidades);
        }
        valormoneda = 1;
        if (cantidad >= valormoneda) {
            unidades = (int) (cantidad / valormoneda);
            cantidad = cantidad % valormoneda;
            System.out.println("Nº billetes " + valormoneda + " : " + unidades);
        }
        valormoneda = 0.5;
        if (cantidad >= valormoneda) {
            unidades = (int) (cantidad / valormoneda);
            cantidad = cantidad % valormoneda;
            System.out.println("Nº billetes " + valormoneda + " : " + unidades);
        }
        valormoneda = 0.2;
        if (cantidad >= valormoneda) {
            unidades = (int) (cantidad / valormoneda);
            cantidad = cantidad % valormoneda;
            System.out.println("Nº billetes " + valormoneda + " : " + unidades);
        }
        valormoneda = 0.05;
        if (cantidad >= valormoneda) {
            unidades = (int) (cantidad / valormoneda);
            cantidad = cantidad % valormoneda;
            System.out.println("Nº billetes " + valormoneda + " : " + unidades);
        }

    }
}
