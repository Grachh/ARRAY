
public class Time {
	
	// ATRIBUTOS O CAMPOS
	private int hh;
	private int mm;
	private int ss;
	public Time() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Time(int hh, int mm, int ss) { // PARAMETROS O ARGUMENTOS
		super();
		this.hh = hh;
		this.mm = mm;
		this.ss = ss;
	}
	@Override
	public String toString() {
		return "Time [hh=" + hh + ", mm=" + mm + ", ss=" + ss + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + hh;
		result = prime * result + mm;
		result = prime * result + ss;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Time other = (Time) obj;
		if (hh != other.hh)
			return false;
		if (mm != other.mm)
			return false;
		if (ss != other.ss)
			return false;
		return true;
	}
	public int getHh() {
		return hh;
	}
	public void setHh(int hh) {
		this.hh = hh;
	}
	public int getMm() {
		return mm;
	}
	public void setMm(int mm) {
		this.mm = mm;
	}
	public int getSs() {
		return ss;
	}
	public void setSs(int ss) {
		this.ss = ss;
	}
	
	
}
