

public class PruebaClock {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Date d1 = new Date();
		System.out.println(d1);
		d1.setAnio(1999);
		System.out.println(d1);
		
		Date d2 = new Date(28,2,2020);
		System.out.println(d2);

		Time t1 = new Time(23,59,55);
		System.out.println(t1);
		
		Dial dial1 = new Dial(93.5, "Cadena Ser");
		System.out.println(d1);
		
		Clock c1 = new Clock (t1, d2, dial1);
		System.out.println(c1);
		
		Clock c2 = new Clock();
		System.out.println("Valor inicial : " + c2);
		ClockLib.configureTime(c2, t1);
		ClockLib.configureDate(c2, d2);
		ClockLib.configureDial(c2, dial1);
		System.out.println("Valor final : " +c2);
		
		c2.init();
		

	}

}
