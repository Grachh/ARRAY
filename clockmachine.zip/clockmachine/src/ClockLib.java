
public class ClockLib {

	public static Clock configureTime (Clock c, Time t)
	{
		c.setH(t);
		return c;
		
	}
	public static Clock configureDate (Clock c, Date d)
	{
		c.setF(d);
		return c;
		
	}
	public static Clock configureDial (Clock c, Dial d)
	{
		c.setM(d);
		return c;
		
	}
	
	public static void init (Clock c)
	{
		
	}
	
}
