
public class Dial {

	private double frec;
	private String cadena;
	
	
	public Dial() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Dial(double frec, String cadena) {
		super();
		this.frec = frec;
		this.cadena = cadena;
	}
	@Override
	public String toString() {
		return "Dial [frec=" + frec + ", cadena=" + cadena + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cadena == null) ? 0 : cadena.hashCode());
		long temp;
		temp = Double.doubleToLongBits(frec);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Dial other = (Dial) obj;
		if (cadena == null) {
			if (other.cadena != null)
				return false;
		} else if (!cadena.equals(other.cadena))
			return false;
		if (Double.doubleToLongBits(frec) != Double.doubleToLongBits(other.frec))
			return false;
		return true;
	}
	public double getFrec() {
		return frec;
	}
	public void setFrec(double frec) {
		this.frec = frec;
	}
	public String getCadena() {
		return cadena;
	}
	public void setCadena(String cadena) {
		this.cadena = cadena;
	}
	
	
}
