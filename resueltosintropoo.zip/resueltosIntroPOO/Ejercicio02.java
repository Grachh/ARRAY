public class Ejercicio02 {

    public static void main(String[] args) {

	Punto p = new Punto(1.0, 1.0);

        System.out.println("X = "+p.coordX);
        System.out.println("Y = "+p.coordY);
	p.coordX = 5.0;
	p.coordY = -1.4;
	System.out.println("------");
        System.out.println("X = "+p.coordX);
        System.out.println("Y = "+p.coordY);
    }

}
