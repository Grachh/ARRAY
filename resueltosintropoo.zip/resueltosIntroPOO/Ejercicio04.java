public class Ejercicio04 {

    public static void main(String[] args) {

	Punto p = new Punto(1.0, 1.0);
	Punto q = new Punto(-1.0, -1.0);
	Punto r = new Punto(-0.56, 7.8);

	System.out.print("|p| = ");
	p.distanciaOrigen();
	System.out.print("|q| = ");
	q.distanciaOrigen();
	System.out.print("|r| = ");
	r.distanciaOrigen();
	
	p.primerCuadrante();
	q.primerCuadrante();
	r.primerCuadrante();
        System.out.println("p.coordX = "+p.coordX);
        System.out.println("p.coordY = "+p.coordY);
	System.out.print("|p| = ");
	p.distanciaOrigen();
        System.out.println("q.coordX = "+q.coordX);
        System.out.println("q.coordY = "+q.coordY);
	System.out.print("|q| = ");
	q.distanciaOrigen();
        System.out.println("r.coordX = "+r.coordX);
        System.out.println("r.coordY = "+r.coordY);
	System.out.print("|r| = ");
	r.distanciaOrigen();

    }

}
