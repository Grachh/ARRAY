public class Ejercicio09 {

    public static void main(String[] args) {

	Circulo2 a = new Circulo2(new Punto(0.0, 0.0), 1.0);
	Circulo2 b = new Circulo2(new Punto(0.0, 0.0), 7.5);
	Circulo2 c = new Circulo2(new Punto(0.0, 0.0), 11e-5);

	b.centro.coordX = 10.0;
	b.centro.coordY = -1.0;

	c.centro.coordX = -9.0;
	c.centro.coordY = 0.56;

	System.out.println("a");
	System.out.println("diametro : "+a.diametro());
	System.out.println("longitud : "+a.longitud());
	System.out.println("area     : "+a.area());
	System.out.println("");

	System.out.println("b");
	System.out.println("diametro : "+b.diametro());
	System.out.println("longitud : "+b.longitud());
	System.out.println("area     : "+b.area());
	System.out.println("");

	System.out.println("c");
	System.out.println("diametro : "+c.diametro());
	System.out.println("longitud : "+c.longitud());
	System.out.println("area     : "+c.area());
	System.out.println("");

    }

}