public class Ejercicio03 {

    public static void main(String[] args) {

	Punto p = new Punto(1.0, 1.0);
	Punto q = new Punto(-1.0, -1.0);
	Punto r = new Punto(-0.56, 7.8);

	p.distanciaOrigen();
	q.distanciaOrigen();
	r.distanciaOrigen();
    }

}
