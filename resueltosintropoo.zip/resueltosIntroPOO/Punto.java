public class Punto {

    public double coordX;
    public double coordY;

    public Punto(double x, double y) {
	coordX = x;
	coordY = y;
    }

    public int cuadrante() {

	int cuad = 0;

	if ((coordX >= 0.0) && (coordY >= 0.0))
	    cuad = 1;
	else if ((coordX < 0.0) && (coordY >= 0.0))
	    cuad = 2;
	else if ((coordX < 0.0) && (coordY < 0.0))
	    cuad = 3;
	else
	    cuad = 4;

	return cuad;
    }

    public void distanciaOrigen() {

	double dist = Math.sqrt((coordX*coordX+coordY*coordY));
	System.out.println(dist);

    }

    public void primerCuadrante() {

	coordX = Math.abs(coordX);
	coordY = Math.abs(coordY);
    }

}
