public class Circulo {

    public Punto centro;
    public double radio;

    public Circulo(double x, double y, double r) {
	centro = new Punto(x, y);
	radio = r;
    }

    public double diametro() {
	return (radio*2.0);
    }

    public double longitud() {
	return (radio*2.0*Math.PI);
    }

    public double area() {
	return (Math.PI*Math.pow(radio,2));
    }
}
