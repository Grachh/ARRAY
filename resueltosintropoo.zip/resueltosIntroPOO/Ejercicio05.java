public class Ejercicio05 {

    public static void main(String[] args) {

	Punto p = new Punto(-2.0, 1.0);
	Punto q = new Punto(-10.0, -2.5);
	Punto r = new Punto(5.2, -1.0);
	Punto s = new Punto(-1550.025,-4E-2);

        System.out.println("p.coordX = "+p.coordX);
        System.out.println("p.coordY = "+p.coordY);
	System.out.print("|p| = ");
	p.distanciaOrigen();
        System.out.println("q.coordX = "+q.coordX);
        System.out.println("q.coordY = "+q.coordY);
	System.out.print("|q| = ");
	q.distanciaOrigen();
        System.out.println("r.coordX = "+r.coordX);
        System.out.println("r.coordY = "+r.coordY);
	System.out.print("|r| = ");
	r.distanciaOrigen();
        System.out.println("s.coordX = "+s.coordX);
        System.out.println("s.coordY = "+s.coordY);
	System.out.print("|s| = ");
	s.distanciaOrigen();

	System.out.println("-------------");
	
	p.primerCuadrante();
	q.primerCuadrante();
	r.primerCuadrante();
	s.primerCuadrante();

        System.out.println("p.coordX = "+p.coordX);
        System.out.println("p.coordY = "+p.coordY);
	System.out.print("|p| = ");
	p.distanciaOrigen();
        System.out.println("q.coordX = "+q.coordX);
        System.out.println("q.coordY = "+q.coordY);
	System.out.print("|q| = ");
	q.distanciaOrigen();
        System.out.println("r.coordX = "+r.coordX);
        System.out.println("r.coordY = "+r.coordY);
	System.out.print("|r| = ");
	r.distanciaOrigen();
        System.out.println("s.coordX = "+s.coordX);
        System.out.println("s.coordY = "+s.coordY);
	System.out.print("|s| = ");
	s.distanciaOrigen();

    }

}
