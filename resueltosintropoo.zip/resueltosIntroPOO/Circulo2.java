public class Circulo2 {

    public Punto centro;
    public double radio;

    public Circulo2(Punto c, double r) {
	centro = c;
	radio = r;
    }

    public double diametro() {
	return (radio*2.0);
    }

    public double longitud() {
	return (radio*2.0*Math.PI);
    }

    public double area() {
	return (Math.PI*Math.pow(radio,2));
    }
}
