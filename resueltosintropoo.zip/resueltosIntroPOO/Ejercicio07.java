public class Ejercicio07 {

    public static void main(String[] args) {

	Circulo a = new Circulo(0.0, 0.0, 1.0);
	Circulo b = new Circulo(10.0, -1.0, 7.5);
	Circulo c = new Circulo(-9.0, 0.56, 11e-5);

	System.out.println("a");
	System.out.println("diametro : "+a.diametro());
	System.out.println("longitud : "+a.longitud());
	System.out.println("area     : "+a.area());
	System.out.println("");

	System.out.println("b");
	System.out.println("diametro : "+b.diametro());
	System.out.println("longitud : "+b.longitud());
	System.out.println("area     : "+b.area());
	System.out.println("");

	System.out.println("c");
	System.out.println("diametro : "+c.diametro());
	System.out.println("longitud : "+c.longitud());
	System.out.println("area     : "+c.area());
	System.out.println("");

    }

}