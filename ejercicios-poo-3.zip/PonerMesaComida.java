/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public class PonerMesaComida implements PonerMesa{

    public String colocarCocina() {
        return "Colocar cocina para comida";
    }

    public String vaciarNevera() {
        return "vaciar nevera para comida";
    }

    public String ponerMenaje() {
        return "poner menaje para comida";
    }
     

}
