/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public interface PonerMesa {

    public String colocarCocina();
    public String vaciarNevera();
    public String ponerMenaje();
}
