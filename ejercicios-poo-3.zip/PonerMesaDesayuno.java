/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public class PonerMesaDesayuno implements PonerMesa{

    public String colocarCocina() {
        return "Colocar cocina para desayuno";
    }

    public String vaciarNevera() {
        return "vaciar nevera para desayuno";
    }

    public String ponerMenaje() {
        return "poner menaje para desayuno";
    }


}
