/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public class Español extends Persona implements Hablador {

    public String saluda() {
        return "Hola";
    }



}
