/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public interface Instrumento {
    public String Tocar();
    public String Tipo();
    public void Afinar();
}
