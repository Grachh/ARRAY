/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public class Animal implements Hablador{

    public String saluda() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
