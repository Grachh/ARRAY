/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public class PonerMesaCena implements PonerMesa{

    public String colocarCocina() {
        return "Colocar cocina para cena";
    }

    public String vaciarNevera() {
        return "vaciar nevera para cena";
    }

    public String ponerMenaje() {
        return "poner menaje para cena";
    }


}
