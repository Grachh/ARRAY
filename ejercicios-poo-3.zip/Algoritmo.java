
public interface Algoritmo
{
// Métodos.
public int encriptar(int param);
public int desencriptar(int param);
}

