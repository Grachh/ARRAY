/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public class Cilindro extends Figura {
    private double x;
    private double y;
    private double radio;
    private double altura;

    @Override
    public double obtenerArea() {
        return 2*(Math.PI * Math.pow(this.radio, 2)) + (2*Math.PI*this.radio*this.altura);
    }

    @Override
    public double obtenerVolumen() {
        return Math.PI * Math.pow(this.radio, 2) * this.altura;
    }

    @Override
    public String obtenerNombre() {
        return "Cilindro";
    }


}
