/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public class Coche {
    private String color;
    private String marca;
    private String modelo;
    private int numCaballos;
    private int numPuertas;
    private String matricula;

    Coche(){}; //Constructor para ejercicio3

    Coche(String marca, String modelo, int numPuertas, String matricula){
        this.marca = marca;
        this.modelo = modelo;
        this.numPuertas = numPuertas;
        this.matricula = matricula;
    }


    void acelerar(){};
    void frenar(){};

     // Setters y Getters del ejercicio 4

    public String getColor() {
        return color;
    }

    public String getMarca() {
        return marca;
    }

    public String getMatricula() {
        return matricula;
    }

    public String getModelo() {
        return modelo;
    }

    public int getNumCaballos() {
        return numCaballos;
    }

    public int getNumPuertas() {
        return numPuertas;
    }

    public void setColor(String color) {
        this.color = color;
    }




}
