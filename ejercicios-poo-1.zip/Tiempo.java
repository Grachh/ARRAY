/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public class Tiempo {
    private int hora;
    private int minuto;
    private int segundo;

    Tiempo(int hora, int minuto, int segundo){
    	  if ((hora <= 24)&&(hora > 0)
        	this.hora = hora;
        else{
        	System.out.println("Hora incorrecta");
        	this.hora = 1;}
        	if ((minuto <= 59)&&(minuto > 0))
        	 this.minuto = minuto;
        	 else{
        	 System.out.println("Minuto incorrecto");
        	 this.minuto = 1;}
        	if ((segundo <= 59)&&(segundo > 0))
        	 this.segundo = segundo;
        	 else{
        	 System.out.println("Segundo incorrecto");
        	 this.segundo = 1;}
    }

    Tiempo(int hora, int minuto){
        if ((hora <= 24)&&(hora > 0)
        	this.hora = hora;
        else{
        	System.out.println("Hora incorrecta");
        	this.hora = 1;}
        	if ((minuto <= 59)&&(minuto > 0))
        	 this.minuto = minuto;
        	 else{
        	 System.out.println("Minuto incorrecto");
        	 this.minuto = 1;}
        	 this.segundo = 1;
    }

    Tiempo(int hora){
        if ((hora <= 24)&&(hora > 0)
        	this.hora = hora;
        else{
        	System.out.println("Hora incorrecta");
        	this.hora = 1;}
        	this.minuto = 1;
        	 this.segundo = 1;
    }

    public boolean esHoraCorrecta(){
        if ((this.hora > 23) || (this.minuto > 59) || (this.segundo > 59))
            return false;
        else
            return true;
    }

}
