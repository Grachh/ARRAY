package ejer;


public class Persona {
	private String dni;
	private Cuenta[] cuentas;
	private boolean moroso;
	
	Persona(String dni){
		this.dni = dni;
		this.cuentas = new Cuenta[3];
	}
	
	public void anadirCuenta(Cuenta c){
		for (int i = 0;  i<this.cuentas.length;i++){
                        
			if (this.cuentas[i] == null){
				this.cuentas[i] = c;
                                break;
			}
		}
	}
	
	
	public boolean esMoroso(){
		for (int i = 0;  i<this.cuentas.length;i++){
			if ((this.cuentas[i] != null) &&(this.cuentas[i].saldoNegativo())){
				this.moroso = true;
				return true;
			}
			
		}
		return false;
	}
	
	public void pago(String cuenta, double dinero){
		for (int i = 0;  i<this.cuentas.length;i++){
			if (this.cuentas[i].getnumCuenta().equals(cuenta)){
				this.cuentas[i].pagoRecibo(dinero);
				if (this.cuentas[i].saldoNegativo())
					this.moroso = true;
                                break;
			}
		}
		 
	}
	
	public void ingreso(String cuenta, double dinero){
		for (int i = 0;  i<this.cuentas.length;i++){
                       
			if (this.cuentas[i].getnumCuenta().equals(cuenta)){
				this.cuentas[i].reciboAbono(dinero);
				if (this.cuentas[i].saldoNegativo())
                                    this.moroso = true;
                                break;
			}
		}
	}
	
        public void mostrarSaldo(String cuenta){
            for (int i = 0;  i<this.cuentas.length;i++){
		if (this.cuentas[i].getnumCuenta().equals(cuenta)){
                     System.out.println(this.cuentas[i].getSaldo());  
                     break;
                }
                
            }
            
        }


	public boolean todasPositivas(){
		for (int i = 0;  i<this.cuentas.length;i++){
			
                        if ((this.cuentas[i] != null) && (this.cuentas[i].saldoNegativo())){
				return false;
			}
		}
		return true;
	}
	
	public void transferir(String c1, String c2, double dinero){
		for (int i = 0;  i<this.cuentas.length;i++){

			if (this.cuentas[i].getnumCuenta().equals(c1)){
				for (int j = 0;  i<this.cuentas.length;j++){
					if (this.cuentas[j].getnumCuenta().equals(c2)){
						this.cuentas[i].transferirDinero(this.cuentas[j], dinero);
                                                System.out.println("trans");
						break;
					}
                                        
				}
			}
                        break;
		}
		if (this.todasPositivas()){
			this.moroso = false;
		}
		
	}

}
