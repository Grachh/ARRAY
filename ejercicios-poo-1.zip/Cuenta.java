package ejer;


public class Cuenta {
    private String banco;
    private String numCuenta;
    private double saldo;

    Cuenta(String banco, String numCuenta){
        this.banco = banco;
        this.numCuenta = numCuenta;
        this.saldo = 0.0;
    }
    Cuenta(String banco, String numCuenta, double saldo){
        this.banco = banco;
        this.numCuenta = numCuenta;
        this.saldo = saldo;
    }
    
    public String getnumCuenta() {
        return this.numCuenta;
    }

    public double getSaldo() {
        return saldo;
    }

    public void reciboAbono(double abono){
        this.saldo += abono;
    }
    public void pagoRecibo(double recibo){
        this.saldo -= recibo;
    }
    public boolean saldoNegativo(){
    	if (saldo < 0.0){
    		return true;
    	}else{
    		return false;
    	}
    }
    
    public void transferirDinero(Cuenta destino, double dinero){
    	if (this.saldo >= dinero){
    		this.pagoRecibo(dinero);
    		destino.reciboAbono(dinero);
    	}else{
    		System.out.println("No se puede realizar la transferencia");
    	}
    }
    
    

}
