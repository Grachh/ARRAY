/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public class Inmueble {
    protected String direccion;
    protected int metros;
    protected int antiguedad;
    protected double precioBase;

    public Inmueble(String direccion, int metros, int antiguedad, double precioBase) {
        this.direccion = direccion;
        this.metros = metros;
        this.antiguedad = antiguedad;
        this.precioBase = precioBase;
    }

    public double costeTotal(){
        if (this.antiguedad <= 15)
            return (this.precioBase - (100/this.precioBase));
        else
            return (this.precioBase - (200/this.precioBase));
    }

}
