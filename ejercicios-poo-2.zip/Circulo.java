/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public class Circulo extends Punto{
    private int radio;

    Circulo(int x, int y, int radio){
        super(x,y);
        this.radio = radio;
    }

}
