/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public class Piso extends Inmueble {
    private int altura;

    public Piso(String direccion, int metros, int antiguedad, double precioBase, int altura) {
        super(direccion, metros, antiguedad, precioBase);
        this.altura = altura;
    }

    public double costeTotal(){
        double aux = super.costeTotal();
        if (this.altura >= 3)
            return aux + (300/aux);
        else
            return aux;
    }

}
