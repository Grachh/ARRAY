
public class LlamadaLocal extends Llamada
{
// Atributos
private static double precio = 5;
// Constructores
public LlamadaLocal(String origen, String destino, int duracion)
{
    super(origen, destino, duracion);
}
// Métodos
public double calcularPrecio()
{
    return getDuracion() * precio;
}

    @Override
public String toString()
{
    return "LLamada Local #" + getNumOrigen() + " - #" + getNumDestino() + " - " + getDuracion()
+ " sg" + "- precio: " + this.calcularPrecio();
}
}

