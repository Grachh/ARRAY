/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public class Disco extends Recurso {
    private String discografica;

    public Disco(String codigo, String titulo, String autor, String discografica) {
        super(codigo, titulo, autor);
        this.discografica = discografica;
    }

  



}
