/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public class Persona {
    protected String nombre;
    protected String apellido;
    protected String dni;
    protected String estadoCivil;

    Persona(String nombre, String apellido, String dni, String estado){
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.estadoCivil = estado;
    }

}
