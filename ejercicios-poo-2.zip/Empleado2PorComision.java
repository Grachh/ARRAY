/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public class Empleado2PorComision extends Empleado2 {
   	 private double comision;
   		private int ventas;

    public Empleado2PorComision(String nombre, String apellido, String numSeguridadSocial, double salarioBase, double comision, int ventas) {
        super(nombre, apellido, numSeguridadSocial, salarioBase,comision,ventas);
        this.comision = comision;
        this.ventas = ventas;
    }

    @Override
    public double darSalario(){
        return this.ventas*this.comision;
    }

}
