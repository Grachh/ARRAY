public abstract class Llamada
{
// Atributos
private String numOrigen;
private String numDestino ;
private double duracion;
// Constructores
public Llamada(String origen, String destino, double duracion)
{
    this.numOrigen = origen;
    this.numDestino = destino;
    this.duracion = duracion;
}
// Getters
public String getNumOrigen()
{
    return numOrigen;
}
public String getNumDestino()
{
    return numDestino;
}
public double getDuracion()
{
    return duracion;
}
// Métodos
public abstract double calcularPrecio();
}

