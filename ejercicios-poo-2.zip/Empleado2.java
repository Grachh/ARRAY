/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 * clase para el ejercicio 5 de la hoja II
 */
public abstract class Empleado2 {
    protected String nombre;
    protected String apellido;
    protected String numSeguridadSocial;
    protected double salarioBase;

   //  protected double comision;
   //  protected int ventas;

    public Empleado2(String nombre, String apellido, String numSeguridadSocial, double salarioBase, double comision, int ventas) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.numSeguridadSocial = numSeguridadSocial;
     //   this.comision = comision;
     //   this.ventas = ventas;
        this.salarioBase = salarioBase;
    }

    public String getApellido() {
        return apellido;
    }

    public String getNombre() {
        return nombre;
    }

    public String getNumSeguridadSocial() {
        return numSeguridadSocial;
    }

  /*  public double getSalarioBase() {
        return salarioBase;
    }*/

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setNumSeguridadSocial(String numSeguridadSocial) {
        this.numSeguridadSocial = numSeguridadSocial;
    }

    public void setSalarioBase(double salarioBase) {
        this.salarioBase = salarioBase;
    }

   // public abstract double darSalario();



}
