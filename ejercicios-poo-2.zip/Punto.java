/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public class Punto {
  
    protected int x;
    protected int y;


   Punto(int x, int y){
        this.x = x;
        this.y = y;
    }
    @Override
    public String toString(){
        return ("("+this.x+","+this.y+")"+" Cudrante "+ this.Cuadrante());
    }

	public int Cuadrante(){
		if ((this.x >= 0) && (this.y >= 0)){
			return 1;
		}else if ((this.x >= 0) && (this.y < 0)){
			return 2;
		}else if ((this.x < 0) && (this.y >= 0)){
			return 3;
		}else
			return 4;
	}
	
	public boolean equals(Object obj){
		if (obj instanceof Punto){
			Punto p = (Punto)obj;
			if (p.Cuadrante() == this.Cuadrante()){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}		

	}
}
