/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public class Estudiante extends Persona {
    private int curso;

    Estudiante(String nombre, String apellido, String dni, String estado, int curso){
        super(nombre, apellido, dni, estado);
        this.curso = curso;
    }

}
