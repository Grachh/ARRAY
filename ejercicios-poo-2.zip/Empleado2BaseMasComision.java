/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public class Empleado2BaseMasComision extends Empleado2 {
   //  private double salarioBase;
   private double comision;
   private int ventas;

 
    public  Empleado2BaseMasComision(String nombre, String apellido, String numSeguridadSocial, double salarioBase, double comision, int ventas) {
        super(nombre, apellido, numSeguridadSocial,salarioBase,comision,ventas);
        this.comision = comision;
        this.ventas = ventas;
        //this.salarioBase = salarioBase;
    }
    


    
    @Override
    public double darSalario(){
        return this.salarioBase + (ventas*comision);
    }
}
