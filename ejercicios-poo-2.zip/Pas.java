/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public class Pas extends Empleado{
    private String seccion;

    Pas(String nombre, String apellido, String dni, String estado, int año, int despacho, String seccion){
        super(nombre, apellido, dni, estado, año, despacho);
        this.seccion = seccion;

    }


}
