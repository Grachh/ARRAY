/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public class Libro extends Recurso{
    private int numpaginas;

    public Libro(String codigo, String titulo, String autor, int numpaginas) {
        super(codigo, titulo, autor);
        this.numpaginas = numpaginas;
    }

    

}
