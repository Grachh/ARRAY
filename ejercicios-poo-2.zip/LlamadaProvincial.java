public class LlamadaProvincial extends Llamada
{
// Atributos
private static double precio1 = 8;
private static double precio2 = 12;
private static double precio3 = 16;
private int franja = 0;
// Constructores
public LlamadaProvincial(String param1, String param2, int param3, int param4)
{
    super(param1, param2, param3);
    franja = param4;
}
public double calcularPrecio()
{
    if(franja == 1)
        return getDuracion() * precio1;
    else if(franja == 2)
        return getDuracion() * precio2;
    else
        return getDuracion() * precio3;
}

    @Override
public String toString()
{
    return "LLamada Provincial #" + getNumOrigen() + " - #" + getNumDestino() + " - " + getDuracion() + " sg - Franja#" + franja + " - Precio: " + this.calcularPrecio();
}
}

