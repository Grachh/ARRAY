
public class ListaEmpleados {
	
	private Empleado2[] empleados;


        ListaEmpleados(int tamaño){
            this.empleados = new Empleado2[tamaño];
        }

        public void anadirEmpleadoEnPosicion(int i, Empleado2 empleado){
            this.empleados[i] = empleado;
        }

	public void darSalarios(){
		for (int i = 0; i < empleados.length; i++){
                        if (empleados[i] != null){
                            System.out.println(empleados[i].nombre + "," + empleados[i].apellido +": "+ empleados[i].darSalario());
                        }
			
		}
	}
}
