
public class Centralita
{
// Atributos
private int cont;
private double acum;
private Llamada[] lista;
// Getters

Centralita(){
    this.cont = 0;
    this.acum = 0.0;
    this.lista = new Llamada[100];
}

public int getTotalLLamadas()
{
    return cont;
}
public double getTotalFacturado()
{
    return acum;
}

private void añadirALista(Llamada param){
    for (int i = 0; i < this.lista.length; i++){
        if (this.lista[i] == null){
            this.lista[i] = param;
        }
    }
}


public void registrarLlamada(Llamada param)
{
    System.out.println(param.toString());
    cont++;
    acum += param.calcularPrecio();
    this.añadirALista(param);

}
}

