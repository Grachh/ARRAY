/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public class Empleado extends Persona {
    protected int año;
    protected int despacho;

    Empleado(String nombre, String apellido, String dni, String estado, int año, int despacho){
        super(nombre, apellido, dni, estado);
        this.año = año;
        this.despacho = despacho;
    }
}
