/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lguerra
 */
public class Local extends Inmueble{
    private int numVentanas;

    public Local(String direccion, int metros, int antiguedad, double precioBase, int numVentanas) {
        super(direccion, metros, antiguedad, precioBase);
        this.numVentanas = numVentanas;
    }

    public double costeTotal(){
        double aux = super.costeTotal();
        if (super.metros > 50){
            return aux + (100/aux);
        }else if (this.numVentanas < 1){
            return aux - (200/aux);
        }else if (this.numVentanas > 4){
            return aux + (200/aux);
        }else
            return aux;
    }

}
