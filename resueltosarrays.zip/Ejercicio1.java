/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.Scanner;

/**
 *
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        /*
        int lim = 10;
        int c = 1;
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < lim && c != 0; i++, c = sc.nextInt()) {}1
         */

        int lim = 10;
        int c = 1;
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < lim ; i++, c = sc.nextInt()) {
            if (c==0) break;
        }



    }
}
