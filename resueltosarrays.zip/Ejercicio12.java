/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 */
public class Ejercicio12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       int[] v = {3,2,1,4};

       int tmp;

       for (int i=0; i<v.length; i++) {
           for (int j=i; j>0; j--) {
               if (v[j] < v[j-1]) {
                 tmp    = v[j];
                 v[j]   = v[j-1];
                 v[j-1] = tmp;
               }
           }
       }

       for (int valor : v) System.out.print(valor + ", ");
        System.out.println("");
    }

}
