
import java.util.Scanner;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 */
public class Ejercicio15 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Introduzca un numero");
        Scanner sc = new Scanner(System.in);
        int numero = sc.nextInt();
        double min_valor = 0;
        double max_valor = numero;
        double med_valor = (min_valor + max_valor) / 2.0;

        while (Math.abs(med_valor * med_valor - numero) > 0.0001) {
            if (med_valor * med_valor > numero) {
                max_valor = med_valor;
            } else {
                min_valor = med_valor;
            }
            med_valor = (min_valor + max_valor) / 2.0;
        }

        System.out.println("la raiz cuadrada de " + numero + " es " + med_valor);

    }
}
