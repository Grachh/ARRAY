/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 */
public class Ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      int[] a = {1,2,3,4,5,6};

      int suma=0;
      for (int i=0; i<a.length; i++) {
          suma += a[i];
      }

        System.out.println("La suma es " + suma);
    }

}
