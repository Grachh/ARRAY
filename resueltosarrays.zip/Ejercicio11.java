/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 */
public class Ejercicio11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      int[] nvecesporcara = new int[6];

      for (int i=0; i<6000; i++) {
          nvecesporcara[(int)(Math.random()*6.0)]++;
      }

      for (int i=0; i<6; i++) {
          System.out.println("Cara " + (i+1) + " nveces: " + nvecesporcara[i] + " ratio: " + nvecesporcara[i]/6000.0);
      }
    }

}
