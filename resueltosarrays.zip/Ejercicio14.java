
import java.util.Scanner;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 */
public class Ejercicio14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      int v[] = {2,3,4,5,6,7,8,9,10,11,12};

      int menor_pos = 0;
      int mayor_pos = v.length -1;
      int medio_pos = (menor_pos + mayor_pos) / 2;

      System.out.println("Introduzca un valor a buscar");
      Scanner sc = new Scanner(System.in);
      int valor = sc.nextInt();

      int ncomparaciones=0;

      while (menor_pos <= mayor_pos && v[medio_pos]!= valor) {
          if (valor < v[medio_pos])
              mayor_pos = medio_pos - 1;
          else
              menor_pos = medio_pos + 1;
          ncomparaciones+=2;
          medio_pos = (menor_pos + mayor_pos) / 2;
      }
      if (v[medio_pos] == valor) ncomparaciones++; //Si no, el ultimo v[medio_pos] != valor no se contaba

      if (v[medio_pos] == valor)
            System.out.println("Encontrado el valor " + valor);
      else
            System.out.println("No encontrado el valor " + valor);
        System.out.println("Nº comparaciones : " + ncomparaciones);


    }

}
