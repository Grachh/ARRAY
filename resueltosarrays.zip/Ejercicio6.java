
import java.util.Scanner;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 */
public class Ejercicio6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        System.out.println("Introduzca la longitud del array");
        Scanner sc = new Scanner(System.in);
        int lgtud = sc.nextInt();
        System.out.println("Introduzca los " + lgtud + " valores del array");

        int[] valores = new int[lgtud];

        for (int i = 0; i < lgtud; i++) {
            valores[i] = sc.nextInt();
        }

        for (int valor : valores) {
            for (int i = 0; i < valor; i++) {
                System.out.print("*");
            }
            System.out.println("");
        }

    }
}
