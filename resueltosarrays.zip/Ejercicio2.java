/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Scanner;

/**
 *
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca un numero: ");
        int numero = sc.nextInt();

        boolean es_primo = numero % 2 != 0;
        if (es_primo) {
            for (int i = 3; i <= Math.sqrt(numero) && es_primo; i += 2) {
                es_primo = numero % i != 0;
            }
        }

        System.out.print("El numero " + numero);
        if (es_primo) {
            System.out.print(" si ");
        } else {
            System.out.print(" no ");
        }
        System.out.println("es primo");
    }
}
