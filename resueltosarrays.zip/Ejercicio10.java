/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 */
public class Ejercicio10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        int[][] matriz = {{1,2,3},{4,5,6},{7,8,9}};


        // Media, Maximo y Minimo

        int media = 0;
        int max, min;
        max = min = matriz[0][0]; // Un valor inicial

        // Ejemplo de uso con el for avanzado/for each
        for (int[] fila: matriz) {
            for (int valor : fila){
                media += valor;
                if      (valor > max) max = valor;
                else if (valor < min) min = valor;
            }
        }
        System.out.println("Media: " + (double) media/ (matriz.length * matriz[0].length) );
        System.out.println("Max: " + max + " min: " + min);

        // Suma de los valores de la diagonal descendente
        int suma_diag_descend = 0;
        for (int i=0; i<matriz.length; i++) suma_diag_descend += matriz[i][i];
        System.out.println("Diagonal Descendente: " + suma_diag_descend);
        
        // Suma de los valores de la diagonal ascendente
        int suma_diag_ascend = 0;
        for (int i=0; i<matriz.length; i++) suma_diag_ascend += matriz[2-i][i];
        System.out.println("Diagonal Ascendente: " + suma_diag_ascend);
        
        // Suma de los valores que estan por encima de la diagonal descendente
        int suma_encima_descend = 0;
        for (int i=0; i<matriz.length; i++) {
          for (int j=i+1; j<matriz[0].length; j++) 
              suma_encima_descend += matriz[i][j];
        }
        System.out.println("Suma de los valores que están por encima de la diagonal descendente " + suma_encima_descend);
        
        // Suma de los valores que estan por debajo de la diagonal descendente        
        int suma_debajo_descend = 0;
        for (int i=0; i<matriz.length; i++) {
          for (int j=0; j<i; j++) 
              suma_debajo_descend += matriz[i][j];
        }
        System.out.println("Suma de los valores que están por debajo de la diagonal descendente " + suma_debajo_descend);
        

    }
}
