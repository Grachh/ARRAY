/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 */
public class Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] a = {1, 2, 3};
        int[] b = {1, 2, 3,5,6};

        boolean iguales = a.length == b.length;

        for (int i=0; iguales && i<a.length; i++) {
        	iguales = a[i] == b[i];
        }

        if (iguales) System.out.println("Iguales");
        else         System.out.println("No son iguales");
    }
}
