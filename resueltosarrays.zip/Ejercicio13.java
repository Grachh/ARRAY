
import java.util.Scanner;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 */
public class Ejercicio13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6};

        System.out.println("Introduzca un numero a buscar:");
        Scanner sc = new Scanner(System.in);
        int numero = sc.nextInt();

        int pos = 0;
        while (pos < array.length && array[pos] != numero  ) {
            pos++;
        }

        if (pos == array.length)
            System.out.println("No he encontrado el numero " + numero);
        else
            System.out.println("La posicion del numero " + numero + " en el array es " + pos);
    }
}
