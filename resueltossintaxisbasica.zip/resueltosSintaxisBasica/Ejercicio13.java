public class Ejercicio13 {

    public static void main(String[] args) {

        String nombre = " Juan Pérez Martinez";
        int edad = 23;
        String dni = "0123456N";
        String telefono = "911234567";
        String correo = "jueamperez@upm.es";
        System.out.println("############################################");
        System.out.println("Datos personales:");
        System.out.print("Nombre y apellidos: \"");
        System.out.print(nombre);
        System.out.println("\"");
        System.out.print("Edad: ");
        System.out.println(edad);
        System.out.print("DNI: \"");
        System.out.print(dni);
        System.out.println("\"");
        System.out.print("Teléfono de contacto: ");
        System.out.println(telefono);
        System.out.print("Correo electrónico: \"");
        System.out.print(correo);
        System.out.println("\"");
        System.out.println("--------------------------------------------");
        System.out.println("Datos académicos");
        System.out.println("\"Curso1\"");
        System.out.println("\"Curso2\"");
        System.out.println("\"Curso3\"");
        System.out.println("############################################");


    }

}
