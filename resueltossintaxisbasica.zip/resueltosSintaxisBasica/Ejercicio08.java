import java.util.Scanner;

public class Ejercicio08 {

    public static void main(String[] args) {

        Scanner stdIn = new Scanner(System.in);
        System.out.print("Dime un número: ");
        int valor1 = stdIn.nextInt();
        System.out.print("Cuadrado: ");
        int resultado = valor1*valor1;
        System.out.println(resultado);
    }

}
