import java.util.Scanner;

public class Ejercicio11 {

    public static void main(String[] args) {

        Scanner stdIn = new Scanner(System.in);
        System.out.print("Farenheit:");
        float valor = stdIn.nextFloat();
        double resultado = (5.0/9.0)*(valor-32);
        System.out.print("Celsius: ");
        System.out.println(resultado);
    }

}
