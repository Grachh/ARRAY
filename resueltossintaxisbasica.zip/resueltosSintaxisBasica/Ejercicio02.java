public class Ejercicio02 {

    public static void main(String[] args) {

        char ca = 'a', cb = 'b', cc = 'A', cd = 'B';
        int a = (int)ca;
        int b = (int)cb;
        int c = (int)cc;
        int d = (int)cd;
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
    }

}
