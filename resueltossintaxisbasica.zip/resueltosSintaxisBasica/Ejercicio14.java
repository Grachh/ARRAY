/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;
/**
 *
 * @author yogui1
 */
public class Ejercicio14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner stdIn = new Scanner(System.in);
        System.out.println("Introduce los sigientes datos:");
        System.out.print("Nombre: ");
        String nombre = stdIn.next();
        System.out.print("Edad: ");
        int edad = stdIn.nextInt();
        System.out.print("DNI: ");
        String dni = stdIn.next();
        System.out.print("Teléfono de contacto: ");
        String telefono = stdIn.next();
        System.out.print("Correo electrónico: ");
        String correo = stdIn.next();
        
        System.out.println("############################################");
        System.out.println("Datos personales:");
        System.out.print("Nombre y apellidos: \"");
        System.out.print(nombre);
        System.out.println("\"");
        System.out.print("Edad: ");
        System.out.println(edad);
        System.out.print("DNI: \"");
        System.out.print(dni);
        System.out.println("\"");
        System.out.print("Teléfono de contacto: ");
        System.out.println(telefono);
        System.out.print("Correo electrónico: \"");
        System.out.print(correo);
        System.out.println("\"");
        System.out.println("############################################");
    }
}
