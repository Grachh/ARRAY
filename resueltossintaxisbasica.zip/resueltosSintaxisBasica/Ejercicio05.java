import java.util.Scanner;

public class Ejercicio05 {

    public static void main(String[] args) {

        Scanner stdIn = new Scanner(System.in);
        System.out.print("Escribe tu nombre: ");
        String nombre = stdIn.next();
        System.out.print("¡");
        System.out.print(nombre);
        System.out.println(", bienvenido al mundo Java!");
    }

}
