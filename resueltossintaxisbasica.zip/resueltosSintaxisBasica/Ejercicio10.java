public class Ejercicio10 {

    public static void main(String[] args) {

        int var1 = 5;
        System.out.println(var1);
        float var2 = var1/2;
        System.out.println(var2);
        var2 = (float)var1/(float)2;
        System.out.println(var2);
    }
}
