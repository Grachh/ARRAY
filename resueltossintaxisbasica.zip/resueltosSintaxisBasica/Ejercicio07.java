import java.util.Scanner;

public class Ejercicio07 {

    public static void main(String[] args) {

        Scanner stdIn = new Scanner(System.in);
        System.out.print("Dime un número: ");
        int valor1 = stdIn.nextInt();
        System.out.print("Dime otro número: ");
        int valor2 = stdIn.nextInt();
        System.out.print("Suma: ");
        int resultado = valor1+valor2;
        System.out.println(resultado);
    }

}
