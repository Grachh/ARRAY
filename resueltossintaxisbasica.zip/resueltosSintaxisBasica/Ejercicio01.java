public class Ejercicio01 {

    public static void main(String[] args) {

	int a = 16;
	int b = 6;

	int resultado = a + b;
	resultado = resultado - 1; 

        System.out.println(resultado);
    }

}
