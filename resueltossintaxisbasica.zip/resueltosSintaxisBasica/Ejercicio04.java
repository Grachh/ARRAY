import java.util.Scanner;

public class Ejercicio04 {

    public static void main(String[] args) {

        Scanner stdIn = new Scanner(System.in);
        int valor = stdIn.nextInt();
        char c = (char)valor;
        System.out.print(valor);
        System.out.print(" -> ");
        System.out.println(c);
    }

}
