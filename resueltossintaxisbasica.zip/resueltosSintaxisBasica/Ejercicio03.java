public class Ejercicio03 {

    public static void main(String[] args) {

        int ia = 97, ib = 126, ic = 128;
        char a = (char)ia;
        char b = (char)ib;
        char c = (char)ic;
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
    }

}
