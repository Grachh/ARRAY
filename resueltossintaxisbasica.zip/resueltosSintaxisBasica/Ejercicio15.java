import java.util.Scanner;

public class Ejercicio15 {

    public static void main(String[] args) {

        Scanner stdIn = new Scanner(System.in);
        System.out.print("Dime un número: ");
        int valor1 = stdIn.nextInt();
        boolean par = ((valor1%2) == 0);
        String resultado = par ? "Es par" : "No es par";
        System.out.println(resultado);
    }

}
