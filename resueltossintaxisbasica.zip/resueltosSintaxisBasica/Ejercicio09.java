public class Ejercicio09 {

    public static void main(String[] args) {

        double base = 25.0;
        double altura = 22.5;
        double area = base*altura;
        System.out.println(area);
    }

}
